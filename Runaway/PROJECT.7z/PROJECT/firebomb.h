//=============================================================================
//
// �����e���� [firebomb.h]
// Author : �O��q��
//
//=============================================================================
#ifndef _FIREBOMB_H_
#define _FIREBOMB_H_

#include "main.h"
#include "bomb.h"

class CCollisionSphere;

class CFireBomb : public CBomb
{
public:
	CFireBomb(PRIORITY Priority);
	~CFireBomb();
	HRESULT Init(D3DXVECTOR3 pos, D3DXVECTOR3 rot, D3DXVECTOR3 move, float fFriction, float fMaxSpeed, float fGravity);	//������
	void Uninit();		//�I��
	void Update();		//�X�V
	void Draw();		//�`��
	void ZTexDraw();	//�e�p�`��

	static CFireBomb *Create(D3DXVECTOR3 pos, D3DXVECTOR3 rot, D3DXVECTOR3 move, float fFriction, float fMaxSpeed, float fGravity);	//�쐬
private:
	void Explosion(D3DXVECTOR3 pos);	//����
};
#endif