//*****************************************************************************
// �J�E���g�_�E��UI����(countdownUI.h)
// Author : �O��q��
//*****************************************************************************

#ifndef _COUNTDOWNUI_H_
#define _COUNTDOWNUI_H_

#include "ui.h"

class CCountdownUI :public CScene
{
public:

	CCountdownUI(PRIORITY Priority);
	~CCountdownUI();

	HRESULT Init(D3DXVECTOR3);	//������
	void Uninit();	//�I��
	void Update();	//�X�V
	void Draw();	//�`��

	void ZTexDraw() { ; }
	D3DXVECTOR3 GetPos() { return D3DXVECTOR3(0.0f, 0.0f, 0.0f); }
	D3DXVECTOR3 GetRot() { return D3DXVECTOR3(0.0f, 0.0f, 0.0f); }
	D3DXVECTOR3 GetPosOld() { return D3DXVECTOR3(0.0f, 0.0f, 0.0f); }
	float GetRadius() { return 0.0f; }
	void SetPos(D3DXVECTOR3) { ; }

	OBJTYPE GetObjType() { return OBJECTTYPE_UI; }

	static CCountdownUI *Create();	//�쐬
private:
	int m_nTime;	//����
	int m_nPattern;	//�摜�̃p�^�[��
	CUI *m_pUI;		//UI
};
#endif