//=============================================================================
//
// �Ŕ��e���� [poisonbomb.h]
// Author : �O��q��
//
//=============================================================================
#ifndef _POISONBOMB_H_
#define _POISONBOMB_H_

#include "main.h"
#include "bomb.h"

class CCollisionSphere;

class CPoisonBomb : public CBomb
{
public:
	CPoisonBomb(PRIORITY Priority);
	~CPoisonBomb();
	HRESULT Init(D3DXVECTOR3 pos, D3DXVECTOR3 rot, D3DXVECTOR3 move, float fFriction, float fMaxSpeed, float fGravity);	//������
	void Uninit();		//�I��
	void Update();		//�X�V
	void Draw();		//�`��
	void ZTexDraw();	//�e�p�`��

	static CPoisonBomb *Create(D3DXVECTOR3 pos, D3DXVECTOR3 rot, D3DXVECTOR3 move, float fFriction, float fMaxSpeed, float fGravity);	//�쐬
private:
	void Explosion(D3DXVECTOR3 pos);	//����
};
#endif